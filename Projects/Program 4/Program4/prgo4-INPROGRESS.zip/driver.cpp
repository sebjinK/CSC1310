/*
	CSC 1310 Program 4 - Markov Chains
	Sebjin Kennedy and G Harrison Simpson
	driver.cpp
	Creates a Markov chain with the help of markovList.h.
*/

#include <iostream>
//FIXME#include "markovMat.h"
#include "markovList.h"
using namespace std;

int main() {
	//FIXMEmarkovMat* chain = new markovMat("corpus.txt")FIXME;
	markovList* chain = new markovList("corpusTest.txt");
	
	//cout << chain->generate(100) << endl;
	return 0;
}