/*
	CSC 1310 Program 4 - Markov Chains
	Sebjin Kennedy and G Harrison Simpson
	markovList.h
	Included in driver.cpp, holds class for the Markov List.
*/
#ifndef MARKOVLIST_H
#define MARKOVLIST_H

#include<map>
#include<fstream>
#include<sstream>
#include<iostream>
#include<stdlib.h>
using namespace std;

class markovList
{
	private:
		struct edge {
			string value; //value that the edge will go to
			edge* nextInList; //next value in linked list
			float weight; //likelihood this will be selected
			edge(string val, float wordWeight) //Default constructor
			{
				weight = wordWeight;
				value = val;
				nextInList = NULL;
			}
		};
		
		edge** edgeArray;
		int corpusSize;
		
		map<string, edge*> corpus; //map[key] = value
	public:
		markovList(const char*);
		~markovList();
		
		string generate(int);
};

markovList::markovList(const char* filename)
{
	
	ifstream file(filename);
	stringstream parser, splitter;//stream means that we are inputting using >> or <<; parser is key; splitter is value; map(key) = value;
	string line, index, word; 
	float weight;
	edge * newEdge;
	edge * tmp;
	int j = 0;
	srand (time(0));
	
	if(file.good()) 
	{
		//Read in size and dynamically allocate array
		file >> corpusSize;
		file.ignore(1, '\n');
		edgeArray = new edge* [corpusSize];
		for(int i=0; i<corpusSize; i++)
		{
			edgeArray[i] = NULL;
		}

		while(getline(file, line, '\n')) //map every word to a position in the matrix, keep the line in an array of buffers for later
		{
			parser.clear();
			parser << line;
			getline(parser, index,',');	//pulls the first word of the line, which is the node for which we're making a list of neighbors
			cout << "DEBUG: index";
			edgeArray[j] = new edge*;
			edgeArray[j]->value = index;
			tmp = edgeArray[j];
			cout << endl;
			while(getline(parser, word, ','))
			{
				//allocate a new node in the edge list---
				splitter.clear();
				splitter.str(word);
				splitter >> word >> weight;
				//stick word and weight on the node you've just allocatezd---
				newEdge = new edge(word, weight);
				
				//make sure your new node is attached to the list---
				if (!edgeArray[j])
				{
					edgeArray[j] = newEdge;
					tmp = edgeArray[j];
					cout << "\n" << tmp->value;
				}
				else
				{
					tmp->nextInList = newEdge; // i->edge1->edge2->newEdge
					tmp = tmp->nextInList;
					cout << "\n   " << tmp->value;
				}
			}	
			j++;
		}
		//DEBUG: REMOVE ME
		for(int i = 0; i < corpusSize; i++) {
			cout << "EDGELIST AT " << i << ": " << index;
		}
	}
}

markovList::~markovList()
{
	edge* iterator;
	edge* tempDelete;
	
	for(int i = 0; i < corpusSize; i++) {
		iterator = edgeArray[i];
		while(iterator) {
			tempDelete = iterator;
			iterator = iterator->nextInList;
			delete tempDelete;
		}
	}
	delete [] edgeArray;
}
		/*
string markovList::generate(int totalWordsOutputted)
{
	map<string, edge*>::iterator it = corpus.begin();	//initialize an iterator to find a random node in the next line
	advance(it, rand() % corpusSize);	//this grabs a random node from your corpus as a starting point
//write the rest of this
	map<string, edge*>::iterator temp;
	edge * tmpNode; //just in case
	float destinationWeight;
	float tmpWeight = 0;
	string jumbleOfWords = "";//this will be the final jumble of wordds that will have crap added on to it from the corpus 
		
	for (tmp = corpus.begin(); tmp != it; ++tmp) //iterator for loop pulled from his shared link
	{
		tmpNode = it->second;//iterator seocond is the edge pointer of the iterator--tmpNode will
		tmpWeight = (it->second)->weight; 
		destinationWeight = (float)rand() / RAND_MAX;
		while (tmpWeight >= destinationWeight)//iterate through the list till we hit the destination weight
		{
			tmpNode = tmpNode->nextInList;
			destinationWeight += tmpWeight;
		}
		jumbleOfWords += tmpNode->value;
		//jumbleOfWords.append(" ");
		//jumbleOfWords.append(tmpNode->value);
	}		
	return jumbleOfWords;
}

*/
#endif