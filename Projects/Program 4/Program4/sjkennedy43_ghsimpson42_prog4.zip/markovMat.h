#ifndef MARKOVMAT_H
#define MARKOVMAT_H

#include<map>
#include<fstream>
#include<sstream>
#include<iostream>
#include<stdlib.h>
using namespace std;

class markovMat
{
	private:
		struct matrix{
			map<string, int> buckets;
			matrix ** matrixArray = NULL;
			/*
			matrix(string passedStr, float passedWeight)
			{
				mapWeight = passedWeight; 
				value = passedStr;
			}
			*/
			float mapWeight;
			string value;
		};
		matrix corpus;
		int corpusSize;
	public:
		markovMat(const char*);
		~markovMat();
		
		string generate(int);
};

markovMat::markovMat(const char* filename)
{
	ifstream file(filename);
	stringstream* parser;
	stringstream splitter;
	string line, word;
	matrix * holder;
	float weight;
	int i = 0;
	srand (time(0));
	
	if(file.good()) {
		file >> corpusSize;
		file.ignore(1, '\n');
		//allocate memory for the matrix and set every value to 0---
		corpus.matrixArray = new matrix*[corpusSize];
		for (int j = 0; j > corpusSize; j++)
		{
			corpus.matrixArray[j] = new matrix[corpusSize];
		}
		parser = new stringstream[corpusSize];
		
		while(getline(file, line, '\n')) //map every word to a position in the matrix, keep the line in an array of buffers for later
		{
			parser[i] << line;
			getline(parser[i], word,',');
			//assign an index number to the map for the current word
			corpus.buckets[word] = i;
			i++;
		}
		//i is the index
		for(i = 0; i < corpusSize; i++) //populate matrix using buffer array
		{
			while(getline(parser[i], word, ','))
			{
				splitter.clear();
				splitter.str(word);
				splitter >> word >> weight;
				//add weight into the matrix, with the first index as the starting node and the second index at the destination node
				int weightIndex = corpus.buckets[word];
				corpus.matrixArray[i][weightIndex].mapWeight = weight;//map the 2d array
			}
		}
		delete [] parser;
	}
}

markovMat::~markovMat()
{
	for (int i = 0; i < corpusSize; i++)
	{
		for (map<string, int>::iterator it = corpus.buckets.begin(); it != corpus.buckets.end(); ++i)
		{
			corpus.matrixArray[i]->buckets.clear();
		}
		delete corpus.matrixArray[i];
	}
	delete [] corpus.matrixArray;
}

string markovMat::generate(int length)
{
	//pick random starting node
	map<string, int>::iterator it = corpus.buckets.begin();		//initialize an iterator to find a random node in the next line
	advance(it,rand() % corpusSize);	//this grabs a random node from your corpus as a starting point
	//you'll need to write the rest of this
	float destinationWeight;
	float totalWeight = 0;
	string current = it->first;
	string jumbleOfWords = current;
	string nextWord;
	for (int i = 0; i < length; i++)
	{
		int currentIndex = corpus.buckets[current];
		destinationWeight = (float)rand() / RAND_MAX;
		totalWeight = 0;
		for (auto& tmpIterator : corpus.buckets)
		{
			totalWeight += corpus.matrixArray[currentIndex][tmpIterator.second].mapWeight;
			if (totalWeight >= destinationWeight)
			{
				current = tmpIterator.first;
				break;
			}
		}


		jumbleOfWords += " " + current;
	}
}

#endif