#ifndef ARRAYMINHEAP_H
#define ARRAYMINHEAP_H
#include "Creature.h"
#include <iostream>
#include <cmath>


using namespace std;


class ArrayMinHeap
{
    private:
        Creature * heapArray;
        int capacity;
        int heap_size;
        void swap(int i1, int i2)
        {
            Creature temp = heapArray[i1];
            heapArray[i1] = heapArray[i2];
            heapArray[i2] = temp;
        }
        
        int parent(int i)
        {
            return (i - 1) / 2;
        }
        
        int left(int i)
        {
            return (i * 2) + 1;
        }
        
        int right(int i)
        {
            return (i * 2) + 2;
        }
    
    public:
        ArrayMinHeap(int maxCap)
        {
            capacity = maxCap;
            heapArray = new Creature[maxCap];
            heap_size = 0;
        }
        
        ~ArrayMinHeap()
        {
            delete [] heapArray;
        }
        
        void minHeapify(int index)
        {
            int parentIndex = index;

            int rightChildIndex = right(index);
            int leftChildIndex = left(index);


            if (heap_size > leftChildIndex && heapArray[parentIndex].getName() > heapArray[leftChildIndex].getName())
                parentIndex = rightChildIndex;
            if (heap_size > rightChildIndex && heapArray[parentIndex].getName() > heapArray[leftChildIndex].getName())
                parentIndex = leftChildIndex;
            if (parentIndex != index)
            {
                swap(parentIndex, index);
                minHeapify(parentIndex);
            }
        }
        
        Creature peek()
        {
            if (isEmpty())
                return heapArray[0];
            else
                return heapArray[0];
        }
        
        bool remove()
        {
            //SWAP THE FIRST AND LAST 
            if (heap_size == 0)
            {
                cout << "\nEmpty";
                return false;
            }
            else if (heap_size == 1)
            {
                heap_size--;
                return false;
            }
            Creature root = heapArray[0];
            heapArray[0] = heapArray[heap_size - 1];
            heapArray[heap_size - 1] = root;
            heap_size--;
            return true;
        }
        
        void insert(Creature newValue)
        {
            if (heap_size == capacity)
            {
                resizeArray();
            }
            else
            {
                heapArray[heap_size] = newValue;
                heap_size++;
                int i = heap_size - 1;

                while (i > 0 && heapArray[parent(i)].getName() > heapArray[i].getName())
                {
                    swap(i, parent(i));
                    i = parent(i);
                }
            }
        }
        
        void resizeArray()
        {
            int cap = capacity * 2;
            Creature * tempArray = new Creature[cap];

            for (int i = 0; i < capacity; i++)
            {
                tempArray[i] = heapArray[i];
            }
            delete [] heapArray;
            heapArray = tempArray;
            capacity = cap;
        }   
        
        bool isEmpty()
        {
            if (heap_size == 0)
                return true;
            else   
                return false;
        }
        
        int getNumberOfNodes()
        {
            return heap_size;
        }
        
        int getHeight()
        {
            return ceil(log2(heap_size + 1)); // ceiling of log base 2 of heap size + 1
        }
        
        void display()
        {
            if(isEmpty()) 
            {
                cout << "\nERROR: Heap's empty!";
            } 
            else 
            {
                int i = -1; 
                cout << endl;
                while(++i < heap_size) 
                {
                    cout << endl << heapArray[i].getName();
                }
            }
        }
        
        void saveToFile()
        {
            int index = 0; //starts at -1 to avoid 

             //iterate through heap and save each node
            while(index < heap_size) 
            {
                heapArray[index].printCreatureToFile("savedCreatures.txt");
                index++;
            }
        }
};
#endif